/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sena.edu.Modelo;

import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gian Castro
 */
public class hash {
     //CIFRAR CONTRASEÑAS
    public static String getHash(String txt, String hashType){
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance(hashType);
            
            byte[] array = md.digest(txt.getBytes());
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < array.length; i++) {
                sb.append(Integer.toHexString((array[i] & 0xFF ) | 0x100).substring(1,3));
                
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(hash.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    
    }
    
    //RETORNA UN HASH MD5 A PARTIR DE UN TEXTO
    public static String md5 (String txt) {
    return hash.getHash(txt, "MD5");
    }
    
    //RETORNA UN HASH SHA1 A PARTIR DE UN TEXTO 
    public static String sha1 (String txt) {
    return hash.getHash(txt, "SHA1");
    }
}
