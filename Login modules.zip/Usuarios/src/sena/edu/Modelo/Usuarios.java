
package sena.edu.Modelo;

/**
 *
 * @author Gian Castro
 */
public class Usuarios {
    //ATRIBUTOS PROPIOS DE LA CLASE
    private int id;
    private String usuario;
    private String password;
    private String nombre;
    private String correo;
    private String ultima_sesiomn;
    private int id_tipo;
    private String nombre_tipo;
    
    //GETTERS Y SETTERS

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUltima_sesiomn() {
        return ultima_sesiomn;
    }

    public void setUltima_sesiomn(String ultima_sesiomn) {
        this.ultima_sesiomn = ultima_sesiomn;
    }

    public int getId_tipo() {
        return id_tipo;
    }

    public void setId_tipo(int id_tipo) {
        this.id_tipo = id_tipo;
    }
    

    public String getNombre_tipo() {
        return nombre_tipo;
    }

    public void setNombre_tipo(String nombre_tipo) {
        this.nombre_tipo = nombre_tipo;
    }
    
    
    
    
    
    
    
    
    
    
    
    
}
