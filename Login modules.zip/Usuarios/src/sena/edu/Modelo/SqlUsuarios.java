/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sena.edu.Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Gian Castro
 */
public class SqlUsuarios extends Conexion{
    //MÉTODOS DE LA CLASE
    
    public boolean registrar(Usuarios usr){
    
        PreparedStatement ps = null;
        Connection con = getConecxion();
        
        String sql = "INSERT INTO usuarios (usuario, password, nombre, correo, "
                + "id_tipo) VALUES(?,?,?,?,?)";
        
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, usr.getUsuario());
            ps.setString(2, usr.getPassword());
            ps.setString(3, usr.getNombre());
            ps.setString(4, usr.getCorreo());
            ps.setInt(5, usr.getId_tipo());
            ps.execute();
            return true; //SE EJECUTÓ DE FORMA CORRECTA
            
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false; //NO SE EJECUTÓ
    }
    
     public int existeUsuario(String usuario){
    
        PreparedStatement ps = null;
         ResultSet rs = null;
        Connection con = getConecxion();
        
        String sql = "SELECT count(id) FROM usuarios WHERE usuario = ?";
        
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1,usuario);
            rs = ps.executeQuery();
            
            if (rs.next()) 
            {
                return rs.getInt(1);
            }
           
           
            
            
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
          
        }
        return 1;
    }
     
     public boolean esEmail (String correo){
     
     //PATRÓN PARA VALIDAR QUE EL CORREO SEA EMAIL REAL
     String regx = "^[A-Za-z0-9+_.-]+@(.+)$";  

     Pattern pattern = Pattern.compile(regx);
     Matcher matcher = pattern.matcher(correo);
     
     return matcher.find();
     }
    
     public boolean login(Usuarios usr){
    
        PreparedStatement ps = null;
         ResultSet rs = null;
        Connection con = getConecxion();
        
        String sql = "SELECT u.id, u.usuario, u.password, u.nombre, u.id_Tipo, "
  + "t.nombre FROM usuarios AS u INNER JOIN tipo_usuario AS t ON u.id_tipo= t.id WHERE usuario = ?";
        
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1,usr.getUsuario());
            rs = ps.executeQuery();
            
            if (rs.next()) 
            {
                if (usr.getPassword().equalsIgnoreCase(rs.getString(3))) {
                    
                     String sqlUpdate = "UPDATE usuarios SET ultima_sesiomn = ? WHERE id=?";
                     ps = con.prepareStatement(sqlUpdate);
                     ps.setString(1, usr.getUltima_sesiomn());
                     ps.setInt(2, rs.getInt(1));
                     ps.execute();
                   
                    usr.setId(rs.getInt(1));
                    usr.setNombre(rs.getString(4));
                    usr.setId_tipo(rs.getInt(5));
                    usr.setNombre_tipo(rs.getString(6));
                    
                    
                    return true;
                    
                    
                } else {
                    return false;
                }
              
            }
           
           
            
            
        } catch (SQLException ex) {
            Logger.getLogger(SqlUsuarios.class.getName()).log(Level.SEVERE, null, ex);
          
        }
        return false;
    }
    
}
